<?php
    $con= new mysqli("localhost","root","","realestate");

    if (mysqli_connect_errno())
      {
      print "Failed to connect to MySQL: " . mysqli_connect_error();
      }
      
    $streetname = empty($_POST['streetname']) ? '' : $_POST['streetname'];
    $owneremail = empty($_POST['owneremail']) ? '' : $_POST['owneremail'];
    
    /*$result = mysqli_query($con, "SELECT * FROM employees
    WHERE first_name LIKE '%{$name}%' OR last_name LIKE '%{$name}%'");

    //output
    while ($row = mysqli_fetch_array($result)){
        echo $row['first_name'] . " " . $row['last_name'];
        echo "<br>";
    }
    */

    $sql = "DELETE
FROM PROPERTY
WHERE UPPER(ADDRESS) = UPPER('$streetname') AND UPPER(OWNER_EMAIL) = UPPER('$owneremail');
";
if($con->query($sql) === True){
                print "Record Updated! House deleted";
            }
            else{
                print $con->error;
            }

    //Testing
    /*$response = '
        Set up the process to delete ' . $streetname . ' attached to the email ' . $owneremail . '.
    ';

    print $response;*/
    mysqli_close($con);
?>