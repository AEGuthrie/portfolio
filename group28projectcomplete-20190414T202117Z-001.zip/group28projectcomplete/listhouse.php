<?php
    $con= new mysqli("localhost","root","","realestate");

    if (mysqli_connect_errno())
      {
      echo "Failed to connect to MySQL: " . mysqli_connect_error();
      }

    $action = empty($_POST['action']) ? '' : $_POST['action'];

    $prminny = empty($_POST['prminny']) ? '' : $_POST['prminny'];
    $sfminny = empty($_POST['sfminny']) ? '' : $_POST['sfminny'];
    $bedminny = empty($_POST['bedminny']) ? '' : $_POST['bedminny'];
    $bathminny = empty($_POST['bathminny']) ? '' : $_POST['bathminny'];
    $ybminny = empty($_POST['ybminny']) ? '' : $_POST['ybminny'];
    $lsminny = empty($_POST['lsminny']) ? '' : $_POST['lsminny'];
    $streetname = empty($_POST['streetname']) ? '' : $_POST['streetname'];
    $cityname = empty($_POST['cityname']) ? '' : $_POST['cityname'];
    $stateabb = empty($_POST['stateabb']) ? '' : $_POST['stateabb'];
    $zipcode = empty($_POST['zipcode']) ? '' : $_POST['zipcode'];
    $countryname = empty($_POST['countryname']) ? '' : $_POST['countryname'];
    $email = empty($_POST['email']) ? '' : $_POST['email'];


    /*$result = mysqli_query($con, "SELECT * FROM employees
    WHERE first_name LIKE '%{$name}%' OR last_name LIKE '%{$name}%'");

    //output
    while ($row = mysqli_fetch_array($result)){
        echo $row['first_name'] . " " . $row['last_name'];
        echo "<br>";
    }
    mysqli_close($con);*/

    //Testing

    

        $sql = "INSERT INTO PROPERTY
                VALUES ('$streetname', '$cityname', '$stateabb', $zipcode, '$countryname', $sfminny, $ybminny, $bedminny, $bathminny, '$email');";
            if($con->query($sql) === True){
                print "<p class="moonflower center">Record Updated! House has been listed!</p><br>";
            }
            else{
                print $con->error;
            }

    switch ($action) {
        case 'Lease':
            
            $sql = "INSERT INTO RENT (ADDRESS, OWNER_EMAIL, RENT, LIST_DATE)
                    VALUES ('$streetname', '$email', $prminny, '12/05/2018');";
            if($con->query($sql) === True){
                print "";
            }
            else{
                print $con->error;
            }
            $response = '<br><br>
                <p class="moonflower center"> ' . $streetname . '. ' . $cityname .', ' . $stateabb . ' ' . $zipcode . '<br>' . $bathminny . ' baths, ' . $bedminny . ' bedrooms, $' . $prminny . ' a month<br>' . $sfminny . 'Sqr ft, Built in '. $ybminny . '. Listed Today</p><br>
                <br>
                <p class="moonflower center"> Email: ' . $email . '<br>';

            print $response;
            break;
            
        case 'Mortgage':
            
            $sql = "
INSERT INTO FOR_SALE
VALUES ('$streetname', $prminny, '12/05/2018', '$email', 0);";
            $response = '<br><br>
                <p class="moonflower center"> ' . $streetname . '. ' . $cityname .', ' . $stateabb . ' ' . $zipcode . '<br>' . $bathminny . ' baths, ' . $bedminny . ' bedrooms, $' . $prminny . ' a month<br>' . $sfminny . 'Sqr ft, Built in '. $ybminny . '. Listed Today</p><br>
                <br>
                <p class="moonflower center"> Email: ' . $email . '<br>';
            
            if($con->query($sql) === True){
                print "";
            }
            else{
                print $con->error;
            }

            print $response;
            break;
            
    }
mysqli_close($con);
?>