function validateMyForm(){
    return false;
}

$(function(){
    $("#listbtn").click(function(){
        
        var radioValue = $("input[name='optionsb']:checked").val();
        
        console.log(radioValue);
    
        $.post("listhouse.php", 
        {
            prminny: $("#prminny").val(),
            sfminny: $("#sfminny").val(),
            bedminny: $("#bedminny").val(),
            bathminny: $("#bathminny").val(),
            ybminny: $("#ybminny").val(),
            lsminny: $("#lsminny").val(),
            streetname: $("#streetname").val(),
            cityname: $("#cityname").val(),
            stateabb: $("#stateabb").val(),
            zipcode: $("#zipcode").val(),
            countryname: $("#countryname").val(),
            email: $("#email").val(),
            action: radioValue
        },
        
        function(data){
            $("#stage").html(data);
        });
    });
}); 

$(function(){
    $("#createbtn").click(function(){
        
        var radioValue = $("input[name='options']:checked").val();
    
        $.post("createaccount.php", 
        {
            name: $("#name").val(),
            phone: $("#phone").val(),
            email: $("#email").val(),
            action: radioValue
        },
        
        function(data){
            $("#stage").html(data);
        });
    });
}); 

$(function(){
    $("#deletebtn").click(function(){
    
        $.post("deletehouse.php", 
        {
            streetname: $("#streetname").val(),
            owneremail: $("#owneremail").val()
        },
        
        function(data){
            $("#stage").html(data);
        });
    });
});    

$(function(){
    $("#indexbtn").click(function(){
        
        var radioValue = $("input[name='options']:checked").val();
        var prminny = $("#prminny").val();
        var prmaxine = $("#prmaxine").val();
        var cityname = $("#cityname").val();
        
        //window.location = "search.html";
        
        $.post("process.php", 
        {
            prminny: prminny,
            prmaxine: prmaxine,
            cityname: cityname,
            action: radioValue
        },
        function(data){
            $("#stage").html(data);
        });
    });
});


$(function(){
    $("#searchbtn").click(function(){
        
        var radioValue = $("input[name='options']:checked").val();
        
        $.post("process.php", 
        {
            prminny: $("#prminny").val(),
            prmaxine: $("#prmaxine").val(),
            sfminny: $("#sfminny").val(),
            sfmaxine: $("#sfmaxine").val(),
            bedminny: $("#bedminny").val(),
            bedmaxine: $("#bedmaxine").val(),
            bathminny: $("#bathminny").val(),
            bathmaxine: $("#bathmaxine").val(),
            ybminny: $("#ybminny").val(),
            ybmaxine: $("#ybmaxine").val(),
            lsminny: $("#lsminny").val(),
            lsmaxine: $("#lsmaxine").val(),
            dlminny: $("#dlminny").val(),
            dlmaxine: $("#dlmaxine").val(),
            streetname: $("#streetname").val(),
            cityname: $("#cityname").val(),
            stateabb: $("#stateabb").val(),
            zipcode: $("#zipcode").val(),
            countryname: $("#countryname").val(),
            action: radioValue
        },
        function(data){
            $("#stage").html(data);
        });
    });
});