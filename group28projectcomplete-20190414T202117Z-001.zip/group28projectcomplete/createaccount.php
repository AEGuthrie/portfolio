<?php
    $con= new mysqli("localhost","root","","realestate");

    if (mysqli_connect_errno())
      {
      print "Failed to connect to MySQL: " . mysqli_connect_error();
      }
      
    
    $action = empty($_POST['action']) ? '' : $_POST['action'];  
      
    $name = empty($_POST['name']) ? '' : $_POST['name'];
    $phone = empty($_POST['phone']) ? '' : $_POST['phone'];
    $email = empty($_POST['email']) ? '' : $_POST['email'];
    
    /*$result = mysqli_query($con, "SELECT * FROM employees
    WHERE first_name LIKE '%{$name}%' OR last_name LIKE '%{$name}%'");

    //output
    while ($row = mysqli_fetch_array($result)){
        echo $row['first_name'] . " " . $row['last_name'];
        echo "<br>";
    }*/

    //Testing
    switch ($action) {
        case 'Client':
            
            /*mysqli_query($con,  'INSERT INTO CLIENT1
                                VALUES ($email, $name);
                                INSERT INTO CLIENT2
                                VALUES ($email, $phone);');*/
            $sql = "INSERT INTO CLIENT1 (EMAIL, FNAME)
                                VALUES ('$email', '$name');";
            if($con->query($sql) === True){
                print "";
            }
            else{
                print $con->error;
            }
            
            
            $sql = "INSERT INTO CLIENT2 (EMAIL, PHONE)
                                VALUES ('$email', $phone);";
            if($con->query($sql) === True){
                print "Record Updated! Client account created!";
            }
            else{
                print $con->error;
            }
            
    
            /*$response = '
                Set up the process to create a client account with for ' . $name . ' attached to the email ' . $email . ' and phone number ' . $phone . '.
            ';*/

            //print $response;
            break;
            
            
        case 'Owner':
    
            $sql = "INSERT INTO OWNER1 (EMAIL, FNAME)
                                VALUES ('$email', '$name');";
            if($con->query($sql) === True){
                print "";
            }
            else{
                print $con->error;
            }
            
            
            $sql = "INSERT INTO OWNER2 (EMAIL, PHONE)
                                VALUES ('$email', $phone);";
            if($con->query($sql) === True){
                print "Record Updated! Owner account created!";
            }
            else{
                print $con->error;
            }
            
            /*$response = '
                Set up the process to create an owner account with for ' . $name . ' attached to the email ' . $email . ' and phone number ' . $phone . '. Hella!
            ';*/

            /*print $response;*/
            break;
            
    }
    

    
    mysqli_close($con);
?>