<?php
    $con= new mysqli("localhost","root","","realestate");

    if (mysqli_connect_errno())
      {
      echo "Failed to connect to MySQL: " . mysqli_connect_error();
      }

    $action = empty($_POST['action']) ? '' : $_POST['action'];

    $prminny = empty($_POST['prminny']) ? '' : $_POST['prminny'];
    $prmaxine = empty($_POST['prmaxine']) ? '' : $_POST['prmaxine'];
    $sfminny = empty($_POST['sfminny']) ? '' : $_POST['sfminny'];
    $sfmaxine = empty($_POST['sfmaxine']) ? '' : $_POST['sfmaxine'];
    $bedminny = empty($_POST['bedminny']) ? '' : $_POST['bedminny'];
    $bedmaxine = empty($_POST['bedmaxine']) ? '' : $_POST['bedmaxine'];
    $bathminny = empty($_POST['bathminny']) ? '' : $_POST['bathminny'];
    $bathmaxine = empty($_POST['bathmaxine']) ? '' : $_POST['bathmaxine'];
    $ybminny = empty($_POST['ybminny']) ? '' : $_POST['ybminny'];
    $ybmaxine = empty($_POST['ybmaxine']) ? '' : $_POST['ybmaxine'];
    $lsminny = empty($_POST['lsminny']) ? '' : $_POST['lsminny'];
    $lsmaxine = empty($_POST['lsmaxine']) ? '' : $_POST['lsmaxine'];
    $dlminny = empty($_POST['dlminny']) ? '' : $_POST['dlminny'];
    $dlmaxine = empty($_POST['dlmaxine']) ? '' : $_POST['dlmaxine'];
    $streetname = empty($_POST['streetname']) ? '' : $_POST['streetname'];
    $cityname = empty($_POST['cityname']) ? '' : $_POST['cityname'];
    $stateabb = empty($_POST['stateabb']) ? '' : $_POST['stateabb'];
    $zipcode = empty($_POST['zipcode']) ? '' : $_POST['zipcode'];
    $countryname = empty($_POST['countryname']) ? '' : $_POST['countryname'];

        
    if(empty($prminny)){
        $prminny = 0;
    }
    if(empty($prmaxine)){
        $prmaxine = 9999999999;
    }    
    if(empty($sfminny)){
        $sfminny = 0;
    }
    if(empty($sfmaxine)){
        $sfmaxine = 9999999999;
    }    
    if(empty($bedminny)){
        $bedminny = 0;
    }
    if(empty($bedmaxine)){
        $bedmaxine = 9999999999;
    }    
    if(empty($bathminny)){
        $bathminny = 0;
    }
    if(empty($bathmaxine)){
        $bathmaxine = 9999999999;
    }    
    if(empty($ybminny)){
        $ybminny = 0;
    }
    if(empty($ybmaxine)){
        $ybmaxine = 9999999999;
    }    
    if(empty($lsminny)){
        $lsminny = 0;
    }
    if(empty($lsmaxine)){
        $lsmaxine = 9999999999;
    }    
    if(empty($dlminny)){
        $dlminny = 0;
    }
    if(empty($dlmaxine)){
        $dlmaxine = 9999999999;
    }

    /*$result = mysqli_query($con, "SELECT * FROM employees
    WHERE first_name LIKE '%{$name}%' OR last_name LIKE '%{$name}%'");

    //output
    while ($row = mysqli_fetch_array($result)){
        echo $row['first_name'] . " " . $row['last_name'];
        echo "<br>";
    }
    mysqli_close($con);*/

    //Testing
    switch ($action) {
        case 'Buying':
            
            /*$sql = "SELECT P.ADDRESS, P.CITY, P.STATE, P.ZIP, P.NUM_BED, P.NUM_BATH, R.RENT, P.SQR_FT, P.YR_BUILT, R.LIST_DATE
                    FROM PROPERTY P, RENT R
                    WHERE P.ADDRESS = R.ADDRESS  AND R.RENT > $prminny AND R.RENT < $prmaxine 
                        AND P.SQR_FT > $sfminny AND P.SQR_FT < $sfmaxine
                            AND P.NUM_BED > $bedminny AND P.NUM_BED < $bedmaxine
                                AND P.NUM_BATH > $bathminny AND P.NUM_BATH < $bathmaxine
                                    AND P.YR_BUILT > $ybminny AND P.YR_BUILT < $ybmaxine
                                        AND (UPPER(P.ADDRESS) = UPPER('$streetname') OR P.ZIP = $zipcode);";
            */
            
            $sql = "SELECT P.ADDRESS, P.CITY, P.STATE, P.ZIP, P.NUM_BED, P.NUM_BATH, R.COST, P.SQR_FT, P.YR_BUILT, R.LIST_DATE, R.OWNER_EMAIL
				FROM PROPERTY P, FOR_SALE R
                WHERE P.ADDRESS = R.ADDRESS 
					AND R.COST > $prminny AND R.COST < $prmaxine 
                        AND P.SQR_FT > $sfminny AND P.SQR_FT < $sfmaxine
                            AND P.NUM_BED > $bedminny AND P.NUM_BED < $bedmaxine
                                AND P.NUM_BATH > $bathminny AND P.NUM_BATH < $bathmaxine
                                    AND P.YR_BUILT > $ybminny AND P.YR_BUILT < $ybmaxine
                                    ";
            if(!empty($streetname)){
                $sql = $sql . "AND (UPPER(P.ADDRESS) = UPPER('$streetname'))
                ";
            }
            if(!empty($cityname)){
                $sql = $sql . "AND (UPPER(P.CITY) = UPPER('$cityname'))
                ";
            }
            if(!empty($stateabb)){
                $sql = $sql . "AND (UPPER(P.STATE) = UPPER('$stateabb'))
                ";
            }
            if(!empty($zipcode)){
                $sql = $sql . "AND (P.ZIP = $zipcode)
                ";
            }
            if(!empty($countryname)){
                $sql = $sql . "AND (UPPER(P.COUNTRY) = UPPER('$countryname'))
                ";
            }
            
            /*if($con->query($sql) === True){
                print "Yay!";
            }
            else{
                print "FAILURE: ";
                print $con->error;
            }*/
            $result = mysqli_query($con, $sql);

            //output
            while ($row = mysqli_fetch_array($result)){
                echo '<p class="moonflower center"> ' . $row[0] . '. ' . $row[1] .', ' . $row[2] . ' ' . $row[3] . '<br>' . $row[4] . ' baths, ' . $row[5] . ' bedrooms, $' . $row[6] . ' a month<br>' . $row[7] . 'Sqr ft, Built in '. $row[8] . '. Listen on ' . $row[9] . '<br>Email ' . $row[10] . ' for more information</p><br>';
            }
            
            /*$response = '
                <p class="moonflower center"> ' . $streetname . '. ' . $cityname .', ' . $stateabb . ' ' . $zipcode . '<br>' . $bathmaxine . ' baths, ' . $bedmaxine . ' bedrooms, $' . $prminny . ' a month<br>' . $sfminny . 'Sqr ft, Built in '. $ybmaxine . '. Listen on ' . $dlmaxine . '</p><br>
                <p class="moonflower center"> 5782 Hella Ave. Arcadia Bay, OR 97141<br>2 baths, 3 bedrooms, $2500 a month<br>935 Sqr ft, Built in 2001. Listed on 11/11/18</p><br>
                <p class="moonflower center"> 57666 Jetray Ave. Hella Red Bull, OR 97142<br>2 baths, 3 bedrooms, $2500 a month<br>935 Sqr ft, Built in 2001. Listed on 11/11/18</p><br>
                <p class="moonflower center"> 2743 Mango St. Hella Renault, OR 97143<br>2 baths, 3 bedrooms, $2500 a month<br>935 Sqr ft, Built in 2001. Listed on 11/11/18</p><br>
                ';

            print $response;*/
            break;
        
        case 'Renting':
            
            $sql = "SELECT P.ADDRESS, P.CITY, P.STATE, P.ZIP, P.NUM_BED, P.NUM_BATH, R.RENT, P.SQR_FT, P.YR_BUILT, R.LIST_DATE, R.OWNER_EMAIL
				FROM PROPERTY P, RENT R
                WHERE P.ADDRESS = R.ADDRESS 
					AND R.RENT > $prminny AND R.RENT < $prmaxine 
                        AND P.SQR_FT > $sfminny AND P.SQR_FT < $sfmaxine
                            AND P.NUM_BED > $bedminny AND P.NUM_BED < $bedmaxine
                                AND P.NUM_BATH > $bathminny AND P.NUM_BATH < $bathmaxine
                                    AND P.YR_BUILT > $ybminny AND P.YR_BUILT < $ybmaxine
                                    ";
            if(!empty($streetname)){
                $sql = $sql . "AND (UPPER(P.ADDRESS) = UPPER('$streetname'))
                ";
            }
            if(!empty($cityname)){
                $sql = $sql . "AND (UPPER(P.CITY) = UPPER('$cityname'))
                ";
            }
            if(!empty($stateabb)){
                $sql = $sql . "AND (UPPER(P.STATE) = UPPER('$stateabb'))
                ";
            }
            if(!empty($zipcode)){
                $sql = $sql . "AND (P.ZIP = $zipcode)
                ";
            }
            if(!empty($countryname)){
                $sql = $sql . "AND (UPPER(P.COUNTRY) = UPPER('$countryname'))
                ";
            }
            
            /*if($con->query($sql) === True){
                print "Yay!";
            }
            else{
                print "FAILURE: ";
                print $con->error;
            }*/
            $result = mysqli_query($con, $sql);

            //output
            while ($row = mysqli_fetch_array($result)){
                echo '<p class="moonflower center"> ' . $row[0] . '. ' . $row[1] .', ' . $row[2] . ' ' . $row[3] . '<br>' . $row[4] . ' baths, ' . $row[5] . ' bedrooms, $' . $row[6] . ' a month<br>' . $row[7] . 'Sqr ft, Built in '. $row[8] . '. Listen on ' . $row[9] . '<br>Email ' . $row[10] . ' for more information</p><br>';
            }
            
           /*$response = '
                <p class="moonflower center"> ' . $streetname . '. ' . $cityname .', ' . $stateabb . ' ' . $zipcode . '<br>' . $bathmaxine . ' baths, ' . $bedmaxine . ' bedrooms, $' . $prminny . ' a month<br>' . $sfminny . 'Sqr ft, Built in '. $ybmaxine . '. Listen on ' . $dlmaxine . '</p><br>
                <p class="moonflower center"> 57666 Jetray Ave. Hella Red Bull, OR 97142<br>2 baths, 3 bedrooms, $2500 a month<br>935 Sqr ft, Built in 2001. Listed on 11/11/18</p><br>
                <p class="moonflower center"> 2743 Mango St. Hella Renault, OR 97143<br>2 baths, 3 bedrooms, $2500 a month<br>935 Sqr ft, Built in 2001. Listed on 11/11/18</p><br>
                <p class="moonflower center"> 754 Tdog Ln. Steelport, NY 10586<br>2 baths, 3 bedrooms, $2500 a month<br>935 Sqr ft, Built in 2001. Listed on 11/11/18</p><br>
            '; 

            print $response;*/
            break;
            
        case 'Selling':
            
            $response = '
                
                <script src="profilescript.js"></script>
                <p class="moonflower center">Please confirm your home information is correct and enter in your contact information and sale type.<br>(Values are taken from the min values on the <a href="search.html">Search Page</a>)</p><br><br>
                <p class="moonflower center"> ' . $streetname . '. ' . $cityname .', ' . $stateabb . ' ' . $zipcode . '<br>' . $bathminny . ' baths, ' . $bedminny . ' bedrooms, $' . $prminny . ' a month<br>' . $sfminny . 'Sqr ft, Built in '. $ybminny . '. Listed Today</p><br>
                <br>
                <div class="input-group">
                    <span class="input-group-addon input-sm"> Email </span>
                    <input type="text" class="form-control input-sm" id="email" placeholder="Your Email">
                </div>
                <br>
                <br>
                <div class="btn-group centerdiv searchbuttons" data-toggle="buttons">
                  <label class="btn btn-primary makehalf active">
                    <input type="radio" name="optionsb" autocomplete="off" value="Lease" checked> Lease
                  </label>
                  <label class="btn btn-primary makehalf">
                    <input type="radio" name="optionsb" autocomplete="off" value="Mortgage"> Mortgage
                  </label>
                </div>
                <br>
                <br>
                <div class="input-group plscenterdiv">
                    <button class="btn testerdownloadbtn" id="listbtn">List</button>
                </div>
                ';

            print $response;
            break;
    }
mysqli_close($con);
?>