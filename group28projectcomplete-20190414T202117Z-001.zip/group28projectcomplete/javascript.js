/* JQuery */

 
$(function(){
    $("#navbar").load("navbar.html"); 
    $("#footer").load("footer.html"); 
});



/* JavaScript */
  wow = new WOW(
    {
        boxClass:     'wow',      // default
        animateClass: 'animated', // change this if you are not using animate.css
        offset:       0,          // default
        mobile:       true,       // keep it on mobile
        live:         true        // track if element updates
      }
    )
   wow.init();